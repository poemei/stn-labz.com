<?php

/**
 * Chaos MVC Module Builder Controller
 *
 * Admin-only module creation and signed release packaging.
 *
 * Path: /app/controllers/module_builder.php
 */

/* [AI:OpenAI Codex | 2026-08-26 17:11:20 UTC] */
class module_builder extends controller
{
    /**
     * Display and process the Module Builder administration screen.
     *
     * @param array $params Route parameters.
     *
     * @return void
     */
    public function admin($params = [])
    {
        if (!isset($_SESSION['user_level']) || $_SESSION['user_level'] < 7) {
            header('Location: /auth/login');
            exit;
        }

        require_once APPROOT . '/lib/module_package_builder.php';

        $model = $this->model('module_builder_model');
        $builder = new module_package_builder();
        $message = null;
        $error = null;

        $routeAction = $params[1] ?? null;

        if ($routeAction === 'download') {
            $slug = (string) ($params[2] ?? '');
            $version = (string) ($params[3] ?? '');
            $artifact = (string) ($params[4] ?? '');

            try {
                $builder->downloadArtifact($slug, $version, $artifact);
            } catch (Throwable $exception) {
                http_response_code(404);
                echo htmlspecialchars(
                    $exception->getMessage(),
                    ENT_QUOTES,
                    'UTF-8'
                );
                exit;
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->require_csrf();
            $action = (string) ($_POST['action'] ?? '');

            try {
                if ($action === 'generate_key') {
                    $result = $builder->generateDeveloperKey([
                        'developer_name' => trim(
                            (string) ($_POST['developer_name'] ?? '')
                        ),
                        'developer_id' => trim(
                            (string) ($_POST['developer_id'] ?? '')
                        ),
                        'key_directory' => trim(
                            (string) ($_POST['key_directory'] ?? '')
                        ),
                        'passphrase' => (string) (
                            $_POST['key_passphrase'] ?? ''
                        ),
                    ]);

                    $message = $result['message'];
                } elseif ($action === 'create_project') {
                    $result = $builder->createProject([
                        'name' => trim((string) ($_POST['name'] ?? '')),
                        'slug' => trim((string) ($_POST['slug'] ?? '')),
                        'version' => trim(
                            (string) ($_POST['version'] ?? '')
                        ),
                        'description' => trim(
                            (string) ($_POST['description'] ?? '')
                        ),
                    ]);

                    $message = $result['message'];
                } elseif ($action === 'build_release') {
                    $result = $builder->buildRelease(
                        trim((string) ($_POST['project_slug'] ?? '')),
                        trim((string) ($_POST['release_version'] ?? '')),
                        trim((string) ($_POST['download_url'] ?? '')),
                        (string) ($_POST['signing_passphrase'] ?? '')
                    );

                    $message = $result['message'];
                }
            } catch (Throwable $exception) {
                $error = $exception->getMessage();
            }
        }

        $data = [
            'signing' => $builder->getSigningStatus(),
            'projects' => $model->getProjects(),
            'message' => $message,
            'error' => $error,
        ];

        $this->view('admin/module_builder', $data);
    }
}
/* [End AI:OpenAI Codex] */

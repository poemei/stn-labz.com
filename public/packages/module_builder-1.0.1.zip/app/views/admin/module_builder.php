<?php

/**
 * Chaos MVC Module Builder Admin View
 *
 * Path: /app/views/admin/module_builder.php
 */

/* [AI:OpenAI Codex | 2026-08-26 17:11:20 UTC] */
require APPROOT . '/views/inc/head.php';

$signing = is_array($data['signing'] ?? null)
    ? $data['signing']
    : [];
$projects = is_array($data['projects'] ?? null)
    ? $data['projects']
    : [];
?>

<p>
    <small>
        <a href="/admin">Admin</a> &gt;&gt; <strong>Module Builder</strong>
    </small>
</p>

<div class="container my-3 text-light">
    <div class="mb-4">
        <h1 class="h5 mb-2">Chaos MVC Module Builder</h1>
        <p class="text-secondary mb-0">
            Create an admin-side MVC module project, then package and sign its release.
        </p>
    </div>

    <?php if (!empty($data['message'])) : ?>
        <div class="alert alert-success" role="status">
            <?= htmlspecialchars((string) $data['message'], ENT_QUOTES, 'UTF-8'); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($data['error'])) : ?>
        <div class="alert alert-danger" role="alert">
            <?= htmlspecialchars((string) $data['error'], ENT_QUOTES, 'UTF-8'); ?>
        </div>
    <?php endif; ?>

    <section class="card bg-dark text-white border-secondary card-body mb-4">
        <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
            <div>
                <h2 class="h6 mb-1">Developer Signing Identity</h2>
                <p class="small text-secondary mb-0">
                    One RSA-3072 keypair is reused across this developer's modules.
                </p>
            </div>
            <span class="badge <?= !empty($signing['configured'])
                ? 'text-bg-success'
                : 'text-bg-secondary'; ?>">
                <?= !empty($signing['configured']) ? 'Configured' : 'Not configured'; ?>
            </span>
        </div>

        <?php if (!empty($signing['configured'])) : ?>
            <dl class="row small mb-0">
                <dt class="col-sm-3">Developer</dt>
                <dd class="col-sm-9">
                    <?= htmlspecialchars(
                        (string) ($signing['developer_name'] ?? ''),
                        ENT_QUOTES,
                        'UTF-8'
                    ); ?>
                </dd>
                <dt class="col-sm-3">Key ID</dt>
                <dd class="col-sm-9 text-break">
                    <code><?= htmlspecialchars(
                        (string) ($signing['key_id'] ?? ''),
                        ENT_QUOTES,
                        'UTF-8'
                    ); ?></code>
                </dd>
                <dt class="col-sm-3">Algorithm</dt>
                <dd class="col-sm-9 mb-0">
                    <?= htmlspecialchars(
                        (string) ($signing['algorithm'] ?? ''),
                        ENT_QUOTES,
                        'UTF-8'
                    ); ?>
                </dd>
            </dl>
        <?php else : ?>
            <form method="post" action="/admin/module_builder">
                <?= $this->csrf_field(); ?>
                <input type="hidden" name="action" value="generate_key">

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label" for="developer-name">Developer Name</label>
                        <input
                            class="form-control form-control-sm bg-dark text-white border-secondary"
                            id="developer-name"
                            name="developer_name"
                            required
                        >
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="developer-id">Developer ID</label>
                        <input
                            class="form-control form-control-sm bg-dark text-white border-secondary"
                            id="developer-id"
                            name="developer_id"
                            placeholder="mei"
                            pattern="[a-z0-9][a-z0-9-]{1,62}"
                            required
                        >
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="key-directory">
                            External Key Directory
                        </label>
                        <input
                            class="form-control form-control-sm bg-dark text-white border-secondary"
                            id="key-directory"
                            name="key_directory"
                            placeholder="C:\Users\Mei\Documents\ChaosMVC-Signing"
                            required
                        >
                        <div class="form-text text-secondary">
                            Create this directory first. It must be outside the Chaos MVC project.
                        </div>
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="key-passphrase">
                            Private-Key Passphrase
                        </label>
                        <input
                            class="form-control form-control-sm bg-dark text-white border-secondary"
                            id="key-passphrase"
                            name="key_passphrase"
                            type="password"
                            autocomplete="new-password"
                        >
                        <div class="form-text text-secondary">
                            Optional. The passphrase is never stored by Module Builder.
                        </div>
                    </div>
                </div>

                <button class="btn btn-sm btn-outline-primary mt-3" type="submit">
                    Generate Developer Key
                </button>
            </form>
        <?php endif; ?>
    </section>

    <section class="card bg-dark text-white border-secondary card-body mb-4">
        <h2 class="h6 mb-3">Create Module Project</h2>

        <form method="post" action="/admin/module_builder">
            <?= $this->csrf_field(); ?>
            <input type="hidden" name="action" value="create_project">

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label" for="module-name">Module Name</label>
                    <input
                        class="form-control form-control-sm bg-dark text-white border-secondary"
                        id="module-name"
                        name="name"
                        placeholder="Example Module"
                        required
                        <?= empty($signing['configured']) ? 'disabled' : ''; ?>
                    >
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="module-slug">Module Slug</label>
                    <input
                        class="form-control form-control-sm bg-dark text-white border-secondary"
                        id="module-slug"
                        name="slug"
                        placeholder="example_module"
                        pattern="[a-z][a-z0-9_]{1,62}"
                        required
                        <?= empty($signing['configured']) ? 'disabled' : ''; ?>
                    >
                </div>
                <div class="col-md-2">
                    <label class="form-label" for="module-version">Version</label>
                    <input
                        class="form-control form-control-sm bg-dark text-white border-secondary"
                        id="module-version"
                        name="version"
                        value="1.0.0"
                        required
                        <?= empty($signing['configured']) ? 'disabled' : ''; ?>
                    >
                </div>
                <div class="col-12">
                    <label class="form-label" for="module-description">Description</label>
                    <textarea
                        class="form-control form-control-sm bg-dark text-white border-secondary"
                        id="module-description"
                        name="description"
                        rows="3"
                        required
                        <?= empty($signing['configured']) ? 'disabled' : ''; ?>
                    ></textarea>
                </div>
            </div>

            <button
                class="btn btn-sm btn-outline-primary mt-3"
                type="submit"
                <?= empty($signing['configured']) ? 'disabled' : ''; ?>
            >
                Create Module Project
            </button>
        </form>
    </section>

    <section class="card bg-dark text-white border-secondary card-body mb-4">
        <h2 class="h6 mb-3">Module Projects</h2>

        <?php if ($projects === []) : ?>
            <p class="text-secondary mb-0">No module projects have been created.</p>
        <?php else : ?>
            <?php foreach ($projects as $project) : ?>
                <?php
                $slug = (string) ($project['slug'] ?? '');
                $latest = is_array($project['latest_release'] ?? null)
                    ? $project['latest_release']
                    : null;
                ?>
                <article class="border border-secondary rounded p-3 mb-3">
                    <div class="d-flex justify-content-between gap-3 mb-2">
                        <div>
                            <h3 class="h6 mb-1">
                                <?= htmlspecialchars(
                                    (string) ($project['name'] ?? ''),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                            </h3>
                            <code><?= htmlspecialchars($slug, ENT_QUOTES, 'UTF-8'); ?></code>
                        </div>
                        <span class="text-secondary small">
                            <?= htmlspecialchars(
                                (string) ($project['version'] ?? ''),
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>
                        </span>
                    </div>

                    <p class="small text-secondary text-break">
                        Project files:
                        <?= htmlspecialchars(
                            (string) ($project['source_directory'] ?? ''),
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>
                    </p>

                    <form method="post" action="/admin/module_builder" class="row g-2">
                        <?= $this->csrf_field(); ?>
                        <input type="hidden" name="action" value="build_release">
                        <input type="hidden" name="project_slug" value="<?= htmlspecialchars(
                            $slug,
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>">

                        <div class="col-md-2">
                            <label class="form-label small" for="release-version-<?= htmlspecialchars(
                                $slug,
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>">Version</label>
                            <input
                                class="form-control form-control-sm bg-dark text-white border-secondary"
                                id="release-version-<?= htmlspecialchars(
                                    $slug,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                name="release_version"
                                value="<?= htmlspecialchars(
                                    (string) ($project['version'] ?? '1.0.0'),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                required
                            >
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small" for="download-url-<?= htmlspecialchars(
                                $slug,
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>">Future HTTPS Package URL</label>
                            <input
                                class="form-control form-control-sm bg-dark text-white border-secondary"
                                id="download-url-<?= htmlspecialchars(
                                    $slug,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                name="download_url"
                                type="url"
                                placeholder="https://example.com/modules/<?= htmlspecialchars(
                                    $slug,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>-1.0.0.zip"
                                required
                            >
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small" for="sign-passphrase-<?= htmlspecialchars(
                                $slug,
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>">Key Passphrase</label>
                            <input
                                class="form-control form-control-sm bg-dark text-white border-secondary"
                                id="sign-passphrase-<?= htmlspecialchars(
                                    $slug,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                name="signing_passphrase"
                                type="password"
                                autocomplete="current-password"
                            >
                        </div>
                        <div class="col-12">
                            <button class="btn btn-sm btn-outline-primary" type="submit">
                                Build and Sign Release
                            </button>
                        </div>
                    </form>

                    <?php if ($latest !== null) : ?>
                        <div class="d-flex flex-wrap gap-2 align-items-center mt-3 pt-3 border-top border-secondary">
                            <span class="badge text-bg-success">Signed and verified</span>
                            <a
                                class="btn btn-sm btn-outline-light"
                                href="/admin/module_builder/download/<?= rawurlencode($slug); ?>/<?= rawurlencode(
                                    (string) $latest['version']
                                ); ?>/package"
                            >Download ZIP</a>
                            <a
                                class="btn btn-sm btn-outline-light"
                                href="/admin/module_builder/download/<?= rawurlencode($slug); ?>/<?= rawurlencode(
                                    (string) $latest['version']
                                ); ?>/manifest"
                            >Download Signed JSON</a>
                            <code class="small text-break">
                                <?= htmlspecialchars(
                                    (string) ($latest['sha256'] ?? ''),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                            </code>
                        </div>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</div>

<?php
require APPROOT . '/views/inc/foot.php';
/* [End AI:OpenAI Codex] */

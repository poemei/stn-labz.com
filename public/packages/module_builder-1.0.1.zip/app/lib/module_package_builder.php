<?php

/**
 * Chaos MVC Module Package Builder
 *
 * Creates admin-only MVC module projects and signed release artifacts.
 *
 * Path: /app/lib/module_package_builder.php
 */

/* [AI:OpenAI Codex | 2026-08-26 17:11:20 UTC] */
class module_package_builder
{
    /**
     * Module Builder configuration path.
     *
     * @var string
     */
    private $configFile;

    /**
     * Module Builder data directory.
     *
     * @var string
     */
    private $dataRoot;

    /**
     * Chaos MVC project root.
     *
     * @var string
     */
    private $projectRoot;

    /**
     * Initialize Module Builder paths.
     */
    public function __construct()
    {
        $this->configFile = APPROOT . '/data/module_builder.json';
        $this->dataRoot = APPROOT . '/data/module_builder';
        $this->projectRoot = dirname(APPROOT);
    }

    /**
     * Return public signing configuration for the administration screen.
     *
     * @return array
     */
    public function getSigningStatus()
    {
        $config = $this->loadConfig();
        $signing = $config['signing'] ?? [];
        $keyDirectory = (string) ($signing['key_directory'] ?? '');
        $keyId = (string) ($signing['key_id'] ?? '');

        return [
            'configured' => $keyId !== ''
                && $keyDirectory !== ''
                && is_file($this->privateKeyPath($keyDirectory, $keyId)),
            'developer_name' => (string) (
                $config['developer']['name'] ?? ''
            ),
            'developer_id' => (string) (
                $config['developer']['id'] ?? ''
            ),
            'algorithm' => (string) (
                $signing['algorithm'] ?? 'RSA-SHA256'
            ),
            'key_id' => $keyId,
            'key_directory' => $keyDirectory,
        ];
    }

    /**
     * Generate and store one RSA-3072 developer signing keypair.
     *
     * @param array $input Developer identity and key configuration.
     *
     * @return array
     */
    public function generateDeveloperKey($input)
    {
        $developerName = trim((string) ($input['developer_name'] ?? ''));
        $developerId = $this->validateDeveloperId(
            (string) ($input['developer_id'] ?? '')
        );
        $keyDirectory = trim((string) ($input['key_directory'] ?? ''));
        $passphrase = (string) ($input['passphrase'] ?? '');

        if ($developerName === '') {
            throw new InvalidArgumentException('Developer name is required.');
        }

        $keyDirectory = $this->validateExternalKeyDirectory($keyDirectory);

        if (!extension_loaded('openssl')) {
            throw new RuntimeException('The OpenSSL PHP extension is required.');
        }

        $resource = openssl_pkey_new([
            'private_key_bits' => 3072,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
            'digest_alg' => 'sha256',
        ]);

        if ($resource === false) {
            throw new RuntimeException('RSA-3072 key generation failed.');
        }

        $privateKey = '';
        $exported = openssl_pkey_export(
            $resource,
            $privateKey,
            $passphrase !== '' ? $passphrase : null,
            ['digest_alg' => 'sha256']
        );

        if (!$exported || $privateKey === '') {
            throw new RuntimeException('The private key could not be exported.');
        }

        $details = openssl_pkey_get_details($resource);

        if (
            !is_array($details)
            || (int) ($details['bits'] ?? 0) !== 3072
            || empty($details['key'])
        ) {
            throw new RuntimeException('The generated RSA key failed validation.');
        }

        $publicKey = (string) $details['key'];
        $keyId = $developerId . '-' . substr(
            hash('sha256', $publicKey),
            0,
            16
        );

        $privatePath = $this->privateKeyPath($keyDirectory, $keyId);
        $publicPath = $this->publicKeyPath($keyDirectory, $keyId);

        if (is_file($privatePath) || is_file($publicPath)) {
            throw new RuntimeException('This developer signing key already exists.');
        }

        $this->writePrivateFile($privatePath, $privateKey);
        $this->writeFile($publicPath, $publicKey);

        $config = [
            'developer' => [
                'name' => $developerName,
                'id' => $developerId,
            ],
            'signing' => [
                'algorithm' => 'RSA-SHA256',
                'key_id' => $keyId,
                'key_directory' => $keyDirectory,
                'public_key' => base64_encode($publicKey),
            ],
        ];

        $this->writeJson($this->configFile, $config);

        return [
            'success' => true,
            'message' => 'Developer signing identity created: ' . $keyId,
        ];
    }

    /**
     * Create a new admin-only Chaos MVC module project.
     *
     * @param array $input Module metadata.
     *
     * @return array
     */
    public function createProject($input)
    {
        $config = $this->requireSigningConfig();
        $name = trim((string) ($input['name'] ?? ''));
        $slug = $this->validateSlug((string) ($input['slug'] ?? ''));
        $version = $this->validateVersion((string) ($input['version'] ?? ''));
        $description = trim((string) ($input['description'] ?? ''));

        if ($name === '') {
            throw new InvalidArgumentException('Module name is required.');
        }

        if ($description === '') {
            throw new InvalidArgumentException('Module description is required.');
        }

        $projectDirectory = $this->projectDirectory($slug);

        if (is_dir($projectDirectory)) {
            throw new RuntimeException('A project already exists for this slug.');
        }

        $sourceDirectory = $projectDirectory . '/source';
        $this->ensureDirectory($sourceDirectory . '/app/controllers');
        $this->ensureDirectory($sourceDirectory . '/app/models');
        $this->ensureDirectory($sourceDirectory . '/app/views/admin');

        $this->writeFile(
            $sourceDirectory . '/app/controllers/' . $slug . '.php',
            $this->controllerTemplate($slug, $name)
        );
        $this->writeFile(
            $sourceDirectory . '/app/models/' . $slug . '_model.php',
            $this->modelTemplate($slug, $name)
        );
        $this->writeFile(
            $sourceDirectory . '/app/views/admin/' . $slug . '.php',
            $this->adminViewTemplate($slug, $name)
        );

        $moduleRecord = [
            'name' => $name,
            'module' => $slug,
            'version' => $version,
            'description' => $description,
            'developer' => [
                'name' => (string) $config['developer']['name'],
                'id' => (string) $config['developer']['id'],
            ],
            'signing' => [
                'algorithm' => 'RSA-SHA256',
                'key_id' => (string) $config['signing']['key_id'],
                'public_key' => (string) $config['signing']['public_key'],
            ],
            'files' => [
                'app/controllers/' . $slug . '.php',
                'app/models/' . $slug . '_model.php',
                'app/views/admin/' . $slug . '.php',
            ],
        ];

        $this->writeJson($sourceDirectory . '/module.json', $moduleRecord);
        $this->writeFile(
            $sourceDirectory . '/README.md',
            $this->readmeTemplate($name, $slug, $version, $description)
        );

        $projectRecord = [
            'name' => $name,
            'slug' => $slug,
            'version' => $version,
            'description' => $description,
            'source_directory' => $sourceDirectory,
            'created_at' => gmdate('c'),
            'latest_release' => null,
        ];

        $this->writeJson($projectDirectory . '/project.json', $projectRecord);

        return [
            'success' => true,
            'message' => 'Module project created at ' . $sourceDirectory,
        ];
    }

    /**
     * Package and sign a module project release.
     *
     * @param string $slug        Module slug.
     * @param string $version     Release version.
     * @param string $downloadUrl Absolute HTTPS package URL.
     * @param string $passphrase  Optional private-key passphrase.
     *
     * @return array
     */
    public function buildRelease($slug, $version, $downloadUrl, $passphrase = '')
    {
        $config = $this->requireSigningConfig();
        $slug = $this->validateSlug($slug);
        $version = $this->validateVersion($version);
        $downloadUrl = $this->validateDownloadUrl($downloadUrl);
        $projectDirectory = $this->projectDirectory($slug);
        $projectFile = $projectDirectory . '/project.json';
        $sourceDirectory = $projectDirectory . '/source';

        if (!is_file($projectFile) || !is_dir($sourceDirectory)) {
            throw new RuntimeException('The selected module project does not exist.');
        }

        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('The PHP ZIP extension is required.');
        }

        $moduleFile = $sourceDirectory . '/module.json';
        $moduleRecord = $this->readJson($moduleFile);
        $moduleRecord['version'] = $version;
        $this->writeJson($moduleFile, $moduleRecord);

        $releaseDirectory = $projectDirectory . '/releases/' . $version;
        $this->ensureDirectory($releaseDirectory);
        $packageName = $slug . '-' . $version . '.zip';
        $packagePath = $releaseDirectory . '/' . $packageName;

        if (is_file($packagePath)) {
            throw new RuntimeException('This module release already exists.');
        }

        $this->createZip($sourceDirectory, $packagePath);
        $sha256 = hash_file('sha256', $packagePath);

        if (!is_string($sha256) || strlen($sha256) !== 64) {
            throw new RuntimeException('The module ZIP could not be hashed.');
        }

        $keyId = (string) $config['signing']['key_id'];
        $statement = $this->releaseStatement(
            $slug,
            $version,
            $downloadUrl,
            $sha256,
            $keyId
        );
        $signature = $this->signStatement($statement, $config, $passphrase);

        $manifest = [
            'module' => $slug,
            'version' => $version,
            'download' => $downloadUrl,
            'sha256' => $sha256,
            'key_id' => $keyId,
            'signature' => base64_encode($signature),
        ];

        $manifestName = $slug . '-' . $version . '.json';
        $manifestPath = $releaseDirectory . '/' . $manifestName;
        $this->writeJson($manifestPath, $manifest);

        $this->verifyBuiltRelease($packagePath, $manifest, $config);

        $project = $this->readJson($projectFile);
        $project['version'] = $version;
        $project['latest_release'] = [
            'version' => $version,
            'package' => $packageName,
            'manifest' => $manifestName,
            'sha256' => $sha256,
            'verified_at' => gmdate('c'),
        ];
        $this->writeJson($projectFile, $project);

        return [
            'success' => true,
            'message' => 'Signed module release created and verified.',
        ];
    }

    /**
     * Stream a verified release artifact to the administrator.
     *
     * @param string $slug     Module slug.
     * @param string $version  Release version.
     * @param string $artifact Artifact type: package or manifest.
     *
     * @return never
     */
    public function downloadArtifact($slug, $version, $artifact)
    {
        $slug = $this->validateSlug($slug);
        $version = $this->validateVersion($version);

        if (!in_array($artifact, ['package', 'manifest'], true)) {
            throw new InvalidArgumentException('Unknown release artifact.');
        }

        $extension = $artifact === 'package' ? 'zip' : 'json';
        $path = $this->projectDirectory($slug)
            . '/releases/' . $version
            . '/' . $slug . '-' . $version . '.' . $extension;

        if (!is_file($path)) {
            throw new RuntimeException('Release artifact not found.');
        }

        header('Content-Type: ' . (
            $artifact === 'package'
                ? 'application/zip'
                : 'application/json'
        ));
        header('Content-Disposition: attachment; filename="' . basename($path) . '"');
        header('Content-Length: ' . (string) filesize($path));
        readfile($path);
        exit;
    }

    /**
     * Load the Module Builder configuration.
     *
     * @return array
     */
    private function loadConfig()
    {
        if (!is_file($this->configFile)) {
            return [
                'developer' => ['name' => '', 'id' => ''],
                'signing' => [
                    'algorithm' => 'RSA-SHA256',
                    'key_id' => '',
                    'key_directory' => '',
                    'public_key' => '',
                ],
            ];
        }

        return $this->readJson($this->configFile);
    }

    /**
     * Require a complete signing configuration.
     *
     * @return array
     */
    private function requireSigningConfig()
    {
        $config = $this->loadConfig();

        if (
            empty($config['developer']['name'])
            || empty($config['developer']['id'])
            || empty($config['signing']['key_id'])
            || empty($config['signing']['key_directory'])
            || empty($config['signing']['public_key'])
        ) {
            throw new RuntimeException(
                'Create the developer signing identity before creating modules.'
            );
        }

        return $config;
    }

    /**
     * Validate a developer identifier.
     *
     * @param string $developerId Developer identifier.
     *
     * @return string
     */
    private function validateDeveloperId($developerId)
    {
        $developerId = strtolower(trim($developerId));

        if (!preg_match('/^[a-z0-9][a-z0-9-]{1,62}$/', $developerId)) {
            throw new InvalidArgumentException(
                'Developer ID must use lowercase letters, numbers, and hyphens.'
            );
        }

        return $developerId;
    }

    /**
     * Validate a module slug.
     *
     * @param string $slug Module slug.
     *
     * @return string
     */
    private function validateSlug($slug)
    {
        $slug = strtolower(trim($slug));

        if (!preg_match('/^[a-z][a-z0-9_]{1,62}$/', $slug)) {
            throw new InvalidArgumentException(
                'Module slug must use lowercase letters, numbers, and underscores.'
            );
        }

        return $slug;
    }

    /**
     * Validate a semantic version.
     *
     * @param string $version Module version.
     *
     * @return string
     */
    private function validateVersion($version)
    {
        $version = trim($version);

        if (!preg_match('/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/', $version)) {
            throw new InvalidArgumentException('Use a semantic version such as 1.0.0.');
        }

        return $version;
    }

    /**
     * Validate an absolute HTTPS package URL.
     *
     * @param string $downloadUrl Package download URL.
     *
     * @return string
     */
    private function validateDownloadUrl($downloadUrl)
    {
        $downloadUrl = trim($downloadUrl);

        if (
            filter_var($downloadUrl, FILTER_VALIDATE_URL) === false
            || strtolower((string) parse_url($downloadUrl, PHP_URL_SCHEME)) !== 'https'
        ) {
            throw new InvalidArgumentException(
                'The release download URL must be an absolute HTTPS URL.'
            );
        }

        return $downloadUrl;
    }

    /**
     * Validate that the signing-key directory is outside the project.
     *
     * @param string $directory Signing-key directory.
     *
     * @return string
     */
    private function validateExternalKeyDirectory($directory)
    {
        if ($directory === '' || !is_dir($directory)) {
            throw new InvalidArgumentException(
                'Choose an existing signing-key directory.'
            );
        }

        $resolvedDirectory = realpath($directory);
        $resolvedProject = realpath($this->projectRoot);

        if ($resolvedDirectory === false || $resolvedProject === false) {
            throw new RuntimeException('The signing-key directory could not be resolved.');
        }

        $directoryCheck = $this->normalizedPath($resolvedDirectory);
        $projectCheck = rtrim($this->normalizedPath($resolvedProject), '/') . '/';

        if (str_starts_with($directoryCheck . '/', $projectCheck)) {
            throw new InvalidArgumentException(
                'Signing keys must be stored outside the Chaos MVC project.'
            );
        }

        return $resolvedDirectory;
    }

    /**
     * Normalize a path for boundary comparison.
     *
     * @param string $path Filesystem path.
     *
     * @return string
     */
    private function normalizedPath($path)
    {
        $path = str_replace('\\', '/', $path);

        return DIRECTORY_SEPARATOR === '\\' ? strtolower($path) : $path;
    }

    /**
     * Return one module project directory.
     *
     * @param string $slug Module slug.
     *
     * @return string
     */
    private function projectDirectory($slug)
    {
        return $this->dataRoot . '/projects/' . $slug;
    }

    /**
     * Return the developer private-key path.
     *
     * @param string $directory Key directory.
     * @param string $keyId     Key identifier.
     *
     * @return string
     */
    private function privateKeyPath($directory, $keyId)
    {
        return rtrim($directory, '/\\')
            . DIRECTORY_SEPARATOR . $keyId . '.private.pem';
    }

    /**
     * Return the developer public-key path.
     *
     * @param string $directory Key directory.
     * @param string $keyId     Key identifier.
     *
     * @return string
     */
    private function publicKeyPath($directory, $keyId)
    {
        return rtrim($directory, '/\\')
            . DIRECTORY_SEPARATOR . $keyId . '.public.pem';
    }

    /**
     * Construct the deterministic module release statement.
     *
     * @param string $slug        Module slug.
     * @param string $version     Module version.
     * @param string $downloadUrl Package URL.
     * @param string $sha256      Package SHA-256.
     * @param string $keyId       Developer key identifier.
     *
     * @return string
     */
    private function releaseStatement($slug, $version, $downloadUrl, $sha256, $keyId)
    {
        return "CHAOS-MVC-MODULE-RELEASE\n"
            . 'module=' . $slug . "\n"
            . 'version=' . $version . "\n"
            . 'download=' . $downloadUrl . "\n"
            . 'sha256=' . strtolower($sha256) . "\n"
            . 'key_id=' . $keyId . "\n";
    }

    /**
     * Sign a deterministic module release statement.
     *
     * @param string $statement  Release statement.
     * @param array  $config     Signing configuration.
     * @param string $passphrase Optional private-key passphrase.
     *
     * @return string
     */
    private function signStatement($statement, $config, $passphrase)
    {
        $directory = (string) $config['signing']['key_directory'];
        $keyId = (string) $config['signing']['key_id'];
        $privateKey = file_get_contents($this->privateKeyPath($directory, $keyId));

        if ($privateKey === false) {
            throw new RuntimeException('The developer private key is unavailable.');
        }

        $key = openssl_pkey_get_private(
            $privateKey,
            $passphrase !== '' ? $passphrase : ''
        );

        if ($key === false) {
            throw new RuntimeException('The private key or passphrase is invalid.');
        }

        $signature = '';
        $signed = openssl_sign(
            $statement,
            $signature,
            $key,
            OPENSSL_ALGO_SHA256
        );

        if (!$signed || $signature === '') {
            throw new RuntimeException('The module release could not be signed.');
        }

        $publicKey = base64_decode(
            (string) $config['signing']['public_key'],
            true
        );

        if (
            !is_string($publicKey)
            || openssl_verify(
                $statement,
                $signature,
                $publicKey,
                OPENSSL_ALGO_SHA256
            ) !== 1
        ) {
            throw new RuntimeException('Release signature self-verification failed.');
        }

        return $signature;
    }

    /**
     * Verify the completed package and manifest together.
     *
     * @param string $packagePath Package path.
     * @param array  $manifest    Signed release manifest.
     * @param array  $config      Signing configuration.
     *
     * @return void
     */
    private function verifyBuiltRelease($packagePath, $manifest, $config)
    {
        $actualHash = hash_file('sha256', $packagePath);

        if (!hash_equals((string) $manifest['sha256'], (string) $actualHash)) {
            throw new RuntimeException('The completed package hash does not match.');
        }

        $signature = base64_decode((string) $manifest['signature'], true);
        $publicKey = base64_decode(
            (string) $config['signing']['public_key'],
            true
        );

        if (!is_string($signature) || !is_string($publicKey)) {
            throw new RuntimeException('The completed signature is malformed.');
        }

        $statement = $this->releaseStatement(
            (string) $manifest['module'],
            (string) $manifest['version'],
            (string) $manifest['download'],
            (string) $manifest['sha256'],
            (string) $manifest['key_id']
        );

        if (
            openssl_verify(
                $statement,
                $signature,
                $publicKey,
                OPENSSL_ALGO_SHA256
            ) !== 1
        ) {
            throw new RuntimeException('Completed release verification failed.');
        }

        $zip = new ZipArchive();

        if ($zip->open($packagePath, ZipArchive::CHECKCONS) !== true) {
            throw new RuntimeException('The completed module ZIP is invalid.');
        }

        $zip->close();
    }

    /**
     * Create a deterministic module ZIP from a project source directory.
     *
     * @param string $sourceDirectory Source directory.
     * @param string $packagePath     Destination ZIP path.
     *
     * @return void
     */
    private function createZip($sourceDirectory, $packagePath)
    {
        $zip = new ZipArchive();

        if ($zip->open($packagePath, ZipArchive::CREATE | ZipArchive::EXCL) !== true) {
            throw new RuntimeException('The module ZIP could not be created.');
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(
                $sourceDirectory,
                FilesystemIterator::SKIP_DOTS
            ),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($iterator as $file) {
            if (!$file->isFile() || $file->isLink()) {
                continue;
            }

            $path = $file->getPathname();
            $relativePath = ltrim(
                str_replace('\\', '/', substr($path, strlen($sourceDirectory))),
                '/'
            );

            if ($relativePath === '' || str_contains($relativePath, '../')) {
                $zip->close();
                throw new RuntimeException('An unsafe module path was rejected.');
            }

            if (!$zip->addFile($path, $relativePath)) {
                $zip->close();
                throw new RuntimeException('A module file could not be packaged.');
            }
        }

        if (!$zip->close()) {
            throw new RuntimeException('The module ZIP could not be finalized.');
        }
    }

    /**
     * Create a standard module controller template.
     *
     * @param string $slug Module slug.
     * @param string $name Module name.
     *
     * @return string
     */
    private function controllerTemplate($slug, $name)
    {
        $annotationTime = gmdate('Y-m-d H:i:s') . ' UTC';

        return "<?php\n"
            . "// path: /app/controllers/{$slug}.php\n\n"
            . "/* [AI:OpenAI Codex | {$annotationTime}] */\n"
            . "/**\n * {$name} Controller\n */\n"
            . "class {$slug} extends controller\n{\n"
            . "    /**\n     * Display module administration.\n"
            . "     *\n     * @param array \$params Route parameters.\n"
            . "     *\n     * @return void\n     */\n"
            . "    public function admin(\$params = [])\n    {\n"
            . "        if (!isset(\$_SESSION['user_level']) || \$_SESSION['user_level'] < 7) {\n"
            . "            header('Location: /auth/login');\n            exit;\n        }\n\n"
            . "        \$model = \$this->model('{$slug}_model');\n\n"
            . "        \$this->view('admin/{$slug}', [\n"
            . "            'module' => \$model->getModuleInformation(),\n"
            . "        ]);\n    }\n}\n"
            . "/* [End AI:OpenAI Codex] */\n";
    }

    /**
     * Create a standard module model template.
     *
     * @param string $slug Module slug.
     * @param string $name Module name.
     *
     * @return string
     */
    private function modelTemplate($slug, $name)
    {
        $annotationTime = gmdate('Y-m-d H:i:s') . ' UTC';

        return "<?php\n"
            . "// path: /app/models/{$slug}_model.php\n\n"
            . "/* [AI:OpenAI Codex | {$annotationTime}] */\n"
            . "/**\n * {$name} Model\n */\n"
            . "class {$slug}_model extends model\n{\n"
            . "    /**\n     * Return basic module information.\n"
            . "     *\n     * @return array\n     */\n"
            . "    public function getModuleInformation()\n    {\n"
            . "        return [\n"
            . "            'name' => " . var_export($name, true) . ",\n"
            . "            'slug' => " . var_export($slug, true) . ",\n"
            . "        ];\n    }\n}\n"
            . "/* [End AI:OpenAI Codex] */\n";
    }

    /**
     * Create a standard module administration view template.
     *
     * @param string $slug Module slug.
     * @param string $name Module name.
     *
     * @return string
     */
    private function adminViewTemplate($slug, $name)
    {
        $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
        $annotationTime = gmdate('Y-m-d H:i:s') . ' UTC';

        return "<?php\n"
            . "// path: /app/views/admin/{$slug}.php\n\n"
            . "/* [AI:OpenAI Codex | {$annotationTime}] */\n"
            . "require APPROOT . '/views/inc/head.php';\n?>\n\n"
            . "<p>\n    <small>\n"
            . "        <a href=\"/admin\">Admin</a> &gt;&gt;\n"
            . "        <strong>{$safeName}</strong>\n"
            . "    </small>\n</p>\n\n"
            . "<div class=\"container my-3 text-light\">\n"
            . "    <h1 class=\"h5 mb-3\">{$safeName}</h1>\n"
            . "    <p>Module administration is ready for development.</p>\n"
            . "</div>\n\n<?php\nrequire APPROOT . '/views/inc/foot.php';\n"
            . "/* [End AI:OpenAI Codex] */\n";
    }

    /**
     * Create a starter module README.
     *
     * @param string $name        Module name.
     * @param string $slug        Module slug.
     * @param string $version     Initial version.
     * @param string $description Module description.
     *
     * @return string
     */
    private function readmeTemplate($name, $slug, $version, $description)
    {
        return '# ' . $name . "\n\n"
            . $description . "\n\n"
            . "## Version\n\n" . $version . "\n\n"
            . "## Module Files\n\n```text\n"
            . "/app/controllers/{$slug}.php\n"
            . "/app/models/{$slug}_model.php\n"
            . "/app/views/admin/{$slug}.php\n"
            . "```\n\n"
            . "## Administration\n\n"
            . "Open `/admin/{$slug}` after installing the module.\n";
    }

    /**
     * Read and decode a JSON file.
     *
     * @param string $path JSON path.
     *
     * @return array
     */
    private function readJson($path)
    {
        $json = file_get_contents($path);

        if ($json === false) {
            throw new RuntimeException('A required JSON file could not be read.');
        }

        $data = json_decode($json, true);

        if (!is_array($data)) {
            throw new RuntimeException('A required JSON file is invalid.');
        }

        return $data;
    }

    /**
     * Write JSON atomically.
     *
     * @param string $path JSON path.
     * @param array  $data JSON data.
     *
     * @return void
     */
    private function writeJson($path, $data)
    {
        $json = json_encode(
            $data,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
        );

        if ($json === false) {
            throw new RuntimeException('JSON encoding failed.');
        }

        $this->writeFile($path, $json . "\n");
    }

    /**
     * Write a file atomically.
     *
     * @param string $path    File path.
     * @param string $content File content.
     *
     * @return void
     */
    private function writeFile($path, $content)
    {
        $this->ensureDirectory(dirname($path));
        $temporary = $path . '.tmp-' . bin2hex(random_bytes(6));

        if (file_put_contents($temporary, $content, LOCK_EX) === false) {
            throw new RuntimeException('A Module Builder file could not be written.');
        }

        if (!is_file($path)) {
            if (!rename($temporary, $path)) {
                @unlink($temporary);
                throw new RuntimeException(
                    'A Module Builder file could not be finalized.'
                );
            }

            return;
        }

        /*
         * Windows does not reliably replace an existing file with rename().
         * Preserve the previous file until the replacement succeeds.
         */
        $backup = $path . '.bak-' . bin2hex(random_bytes(6));

        if (!rename($path, $backup)) {
            @unlink($temporary);
            throw new RuntimeException(
                'The existing Module Builder file could not be preserved.'
            );
        }

        if (!rename($temporary, $path)) {
            @rename($backup, $path);
            @unlink($temporary);
            throw new RuntimeException(
                'A Module Builder file could not be replaced.'
            );
        }

        @unlink($backup);
    }

    /**
     * Write a private key with restricted filesystem permissions.
     *
     * @param string $path    Private-key path.
     * @param string $content Private-key content.
     *
     * @return void
     */
    private function writePrivateFile($path, $content)
    {
        $this->writeFile($path, $content);
        @chmod($path, 0600);
    }

    /**
     * Ensure a directory exists.
     *
     * @param string $directory Directory path.
     *
     * @return void
     */
    private function ensureDirectory($directory)
    {
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new RuntimeException('A required Module Builder directory could not be created.');
        }
    }
}
/* [End AI:OpenAI Codex] */

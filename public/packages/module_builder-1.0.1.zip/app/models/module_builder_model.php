<?php

/**
 * Chaos MVC Module Builder Model
 *
 * Reads Module Builder project records without requiring a database table.
 *
 * Path: /app/models/module_builder_model.php
 */

/* [AI:OpenAI Codex | 2026-08-26 17:11:20 UTC] */
class module_builder_model extends model
{
    /**
     * Return all locally created module projects.
     *
     * @return array
     */
    public function getProjects()
    {
        $projectsRoot = APPROOT . '/data/module_builder/projects';

        if (!is_dir($projectsRoot)) {
            return [];
        }

        $projects = [];
        $records = glob($projectsRoot . '/*/project.json') ?: [];

        foreach ($records as $record) {
            $json = file_get_contents($record);

            if ($json === false) {
                continue;
            }

            $project = json_decode($json, true);

            if (!is_array($project)) {
                continue;
            }

            $projects[] = $project;
        }

        usort($projects, static function ($left, $right) {
            return strcmp(
                (string) ($left['name'] ?? ''),
                (string) ($right['name'] ?? '')
            );
        });

        return $projects;
    }
}
/* [End AI:OpenAI Codex] */

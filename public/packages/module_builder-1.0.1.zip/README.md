# module-builder

Create Chaos MVC Modules and Sign them with one simple tool on your Chaos MVC Website.

## Version

1.0.0

## Module Files

```text
/app/controllers/module_builder.php
/app/models/module_builder_model.php
/app/views/admin/module_builder.php
```

## Administration

Open `/admin/module_builder` after installing the module.

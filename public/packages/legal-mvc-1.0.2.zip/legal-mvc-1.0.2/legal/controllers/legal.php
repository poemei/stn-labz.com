<?php
// path: /user/modules/legal/controllers/legal.php

/**
 * Legal Controller
 */
class legal
{
    /**
     * Display Terms of Use.
     *
     * @return void
     */
    public function terms(): void
    {
        $this->view('terms');
    }

    /**
     * Display Privacy Policy.
     *
     * @return void
     */
    public function privacy(): void
    {
        $this->view('privacy');
    }
}